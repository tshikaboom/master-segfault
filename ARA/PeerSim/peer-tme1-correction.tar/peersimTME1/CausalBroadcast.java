package tme1shadow;

import java.util.ArrayList;
import java.util.List;

import peersim.config.Configuration;
import peersim.core.Node;
import peersim.edsim.EDProtocol;
import tme1.BroadcastProtocol;
import tme1.Message;

public class CausalBroadcast implements BroadcastProtocol, EDProtocol {

	private static final String PAR_FIFOBROADCASTID = "fifobroadcast";
	
	private final int protocol_id;
	private final int fifobroadcast_protocol_id;
	
	private List<Message> seqMesg;
	private List<Message> messDelv;
	
	public CausalBroadcast(String prefix) {
		String tmp[]=prefix.split("\\.");
		protocol_id=Configuration.lookupPid(tmp[tmp.length-1]);
		fifobroadcast_protocol_id=Configuration.getPid(prefix+"."+PAR_FIFOBROADCASTID);
		
		seqMesg=new ArrayList<Message>();
		messDelv=new ArrayList<Message>();
	}
	
	public Object clone(){
		CausalBroadcast causalb = null;
		try { causalb = (CausalBroadcast) super.clone();
			causalb.seqMesg=new ArrayList<Message>();
			causalb.messDelv=new ArrayList<Message>();
		}
		catch( CloneNotSupportedException e ) {} // never happens
		return causalb;
	}
	
	
	
	@Override
	public void broadcast(Node src, Message m) {
		FIFOBroadcast b= (FIFOBroadcast) src.getProtocol(fifobroadcast_protocol_id);
		ArrayList<Message> fusion = new ArrayList<Message>(seqMesg);		
		fusion.add(m);
		b.broadcast(src, new Message(m.getIdSrc(), -2, "causalbroadcast", fusion, protocol_id));
		seqMesg.clear();

	}

	@Override
	public void deliver(Node host, Message m) {
		int pid_dessus=m.getPid();
		((EDProtocol)host.getProtocol(pid_dessus)).processEvent(host, pid_dessus, m); 
	}

	@SuppressWarnings("unchecked")
	@Override
	public void processEvent(Node node, int pid, Object event) {
		if(protocol_id != pid){
			throw new RuntimeException("Receive Message for wrong protocol");
		}
		if(event instanceof Message){
			Message m = (Message)event;
			List<Message> l = (List<Message>) m.getContent();
			for(Message mi : l){
				if(!messDelv.contains(mi)){
					deliver(node, mi);
					messDelv.add(mi);
					seqMesg.add(mi);
				}
			}
		}
		
	}

}
