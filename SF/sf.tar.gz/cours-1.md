# SF - Cours 1

Rappel des cours de SF:

- Une formule LTL est une formule $\varphi$
- soit la négation d'un formul
- soit une formule $\land$ une autre formule
- Le $X (next)$ d'une autre formule
- le Finaly $(F)$ d'une formule
- le Globaly $(F)$ d'une formule


### Exercice

vérifer que: t,i $\equiv$ F$\varphi$ ssi t,i $\equiv$ TU$\varphi$
Définition: Il existe j$\geq$ i, t,i$\equiv\varphi$
il existe j$\geq$i, t,j$\equiv\varphi$ et pour tout $i\leq k <j$ t, k $\equiv \top$

vérifier que:
$G\varphi\equiv\lnot F(\lnot \varphi)$

### Exo 1
a) G(trainGvoie => F($\lnot$ trainGvoie)) $\lor$ G(trianDvoie=>F($\lnot$ trainDvoie))
A) G(trainDvoie $\lor$ trainGvoie => F($\lnot$trianDvoie $\land$ $\lnot$trianGvoie))

b) GF(trainGvoie $\lor$ trianDvoie)


c) G(trainGvoie $\land$ trainD => ($\lnot$trainDvoieU$\lnot$trianGvoie))

### Exo 4
a)
1) vrai
2) vrai
3) faux
4) vrai
5) vrai


### Exercice

a) S(EXp): {[1:3], 5, 6}
b) S(AXp): {3, 6}
c) S(EFp): {TOUS}
d) S(AFp): {TOUS !{1,4,8}}
e) S(EqUr): {2, 3, 4, 5, 6}
f) S(AqUr): {2, 3, 4, 5, 6}
